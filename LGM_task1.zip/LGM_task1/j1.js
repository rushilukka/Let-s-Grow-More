function SubmitFun1()
{ let val = document.getElementById("ip").value;
//let str = new String(val); 
if(val==""){   
   alert(`Task can't be empty`);
  return;
}

else{ 
  let table = document.getElementById("myTable");
  let row = table.insertRow(1);
  let cell1 = row.insertCell(0);
  let cell2 = row.insertCell(1);
  let cell3 = row.insertCell(2);
  
cell1.innerHTML = `<input type="checkbox" id="myCheck" onClick="markFun(this)">`;
  cell2.innerHTML =  `<p style="font-family:sans-serif ;font-size:22px;
  color: #555;
  line-height: 40px;
  text-align: center;">`+val+`</p>`;
  cell3.innerHTML = `<button onClick="deleteFun(this)" id="del" ">delete</button>`;
  
 
}
document.getElementById("ip").value='';
  }
function deleteFun(r){
        let i = r.parentNode.parentNode.rowIndex;
  document.getElementById("myTable").deleteRow(i);
}
function markFun(qr){
    let i = qr.parentNode.parentNode.rowIndex;
 let table = document.getElementById("myTable");
 let row = table.rows[i];
 let cell = row.cells[1];
 let cellText = cell.textContent;
 if(qr.checked){ cell.innerHTML = `<del style="font-family:sans-serif ;font-size:22px;
 color: #555;

 line-height: 50px;
 padding:40px;
 text-align: center;">`+cellText +`</del>`;}
 else{cell.innerHTML =`<p style="font-family:sans-serif ;font-size:22px;
 color: #555;
 line-height: 40px;
 text-align: center;">`+ cellText +`</p>`;}
}

