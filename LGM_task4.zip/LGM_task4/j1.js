function appendNumber(number) {
    if(document.getElementById('result').value =='0'){
    document.getElementById('result').value = number;}
else{document.getElementById('result').value += number;}

}

function appendOperator(operator) {
    let y = document.getElementById('result').value;
    let x = y.toString();
    let z = x.length-1 ;
    let w =x.charAt(z); 
    if('*' == w) {alert("no multiple operator allowed");}
    else if('+' == w) {alert("no multiple operator allowed");}
    else if('.' == w) {alert("no multiple operator allowed");}
    else if('/' == w) {alert("no multiple operator allowed");}
    else if('-' == w) {alert("no multiple operator allowed");}
   // else if('*' == w) {alert("no multiple operator allowed");}
    else{
    document.getElementById('result').value += operator;
    }// if(y.charAt(y.length-1) == ('+'||'-'||'*'||'/'||'.')) 
    // { alert("no multiple operator allowed");
    // }
    // else{       y += operator;
    // console.log(y.length);
    // console.log(y.charAt(y.length-1));
    // }   
}

function appendDecimal(decimal) {
    document.getElementById('result').value += decimal;
}

function calculate() {
    try {
        const result = eval(document.getElementById('result').value);
        document.getElementById('result').value = result;
    } catch (error) {
        document.getElementById('result').value = 'Error';
    }
}

function clearInput() {
    document.getElementById('result').value = '0';
}
