function addUser(){
    let x = document.getElementById("cont");
    
    //let z = document.createElement("card")
    let name  = document.getElementById("name").value;
    let email  = document.getElementById("email").value;
    let img  = document.getElementById("img1").value;
    let web  = document.getElementById("web").value;

    let genderM  = document.getElementById("genderM");
    let genderF  = document.getElementById("genderF");
    let gender ='' ;
    if(genderF.checked == true) gender =genderF.value; 
    else if(genderM.checked == true) gender =genderM.value;  
    
  
    let skill1 = document.getElementById("skill1");
    let skill2 = document.getElementById("skill2");
    let skill3 = document.getElementById("skill3");
    let skills = "";
    if(name==''||email==''||img==''||web==''||gender==''||(skill1.checked == false && skill3.checked == false && skill2.checked == false)){
      alert('Please enter data ');
      return;
    }
    else{

    if(skill1.checked == true){skills = skills+" "+skill1.value ;}
    if(skill2.checked == true){skills = skills+" "+skill2.value ;}
    if(skill3.checked == true){skills = skills+" "+skill3.value ;}
    
    
    let y = document.createElement("div");
   
    y.innerHTML = `
    <div class="card m-auto "  id="cardId">
    <div class="row">
     <div class="col-sm-3 float-child1 imgC1">
       <img src=" ${img}" class="rounded-circle " width="200px" height="200px" alt="user Image">
     </div>
     <div class="col-lg float-child2">
       <div class="card-body">
         <h5 class="card-title">Name : `+ name + `</h5>
         <p class="card-text">E-mail : ` + email +`</p>
         <p class="card-text">website : <a href="` + web + `" target="_blank">`+ web + `</a></p>
         <p class="card-text">Gender : ` + gender +`</p>
         <p class="card-text">Skills : ` + skills +`</p>
       
         </div>
     </div>
   </div>
 </div>
 
 <br>
 `;
 console.log(skills);
    x.appendChild(y);
    clearText();
}
}
const clearText=()=>{
  let name  = document.getElementById("name");
    let email  = document.getElementById("email");
    let img  = document.getElementById("img1");
     let web  = document.getElementById("web");
     email.value="";
     img.value="";
     web.value="";
     name.value="";
     
     genderF.checked = false; 
    genderM.checked = false;  
     
      skill1.checked = false;
      skill2.checked = false;
      skill3.checked = false;
    }